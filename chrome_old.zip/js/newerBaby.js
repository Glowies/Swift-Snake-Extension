window.addEventListener('DOMContentLoaded', function(){
    chrome.runtime.onUpdateAvailable.addListener(function(details) {
        console.log("updating to version " + details.version);
        chrome.runtime.reload();
    });

    chrome.runtime.requestUpdateCheck(function(status) {
        if (status == "update_available") {
            console.log("update pending...");
        } else if (status == "no_update") {
            console.log("no update found");
        } else if (status == "throttled") {
            console.log("Oops, I'm asking too frequently - I need to back off.");
        }
    });

    // Credits for update checking code: https://stackoverflow.com/questions/15775187/how-to-cause-a-chrome-app-to-update-as-soon-as-possible

    var data = Object();

    disconnected = true;
    tempNick = "";

    connectSocket(data,'https://snake-leaderboard.herokuapp.com/');

    chrome.storage.sync.get("highScore",function(info){
        if(typeof(info.highScore) == "undefined"){
            chrome.storage.sync.set({'highScore': 0}, function(){});
            $('#highscoreEXT').text('Highscore : 0');
            data.currentHS = 0;
        }else{
            $('#highscoreEXT').text('Highscore : ' + info.highScore);
            data.currentHS = info.highScore;
        }
    });

    chrome.storage.sync.get("nickname",function(info) {
        if(typeof(info.nickname) == "undefined" || info.nickname.replace(/\s/g, '') == "") {
            $('#alertEXT').html('<div class="alert alert-dark" style="width:100%;height:100%;z-index:99;opacity:0.92"><br><br><br><br><br><b>Nickname:</b><br><div class="input-group"><input id="nickInput" maxlength="15" type="text" class="form-control" placeholder="Derpina"><span class="input-group-btn"><button id="nickEnter" class="btn btn-default" type="button">Enter...</button></span></div><br><ul><li>Must be less than 15 characters.</li><li>Cannot contain leading or trailing spaces.</li></ul><span id="errorBox"></span></div>');
            $('#alertEXT').width(800);
            $('#alertEXT').height(500);
            fixUI();

            $('#nickEnter').click(function(){
                enterNickname(data);
            });

            $('#nickInput').keypress(function(){
                try{$('#tempEXT').remove();}catch(err){}
                var inputVal = $('#nickInput').val().replace(/</g," ").replace(/>/g," ");
                $('#nickInput').val(inputVal);
            });
        }else{
            tempNick = info.nickname;
            data.socket.emit('check user', tempNick);
        }
    });

    data.int = 0;
    data.pause = 0;
    data.game = 0;
    data.frameCount = 0;
    view = 0;
    data.queue = [];
    data.dir = "right";
    data.snake = [];
    data.length = 0;
    data.body = [];
    data.wobble = false;

    window.addEventListener("keydown",function(e){
        setdir(e,data);
    }, true);

    canvas = document.getElementById('renderCanvasEXT');

    engine = new BABYLON.Engine(canvas, true);

    var createScene = function(){
        scene = new BABYLON.Scene(engine);

        camera = new BABYLON.ArcRotateCamera("ArcRotateCamera", 0, 0, 0, BABYLON.Vector3.Zero(), scene);
        camera.setPosition(new BABYLON.Vector3(5, 20, -25));
        camera.attachControl(canvas);

        function adjustCamKeys(data) {
            var c = camera;
            c.keysUp = []; // t
            c.keysLeft = []; // f
            c.keysDown = []; // g
            c.keysRight = []; // h
        }

        adjustCamKeys(data);

        setSkyBox();

        // Materials

        data.foodMat = new BABYLON.StandardMaterial("food", scene);
        data.foodMat.specularColor = new BABYLON.Color3(0, 0, 0);

        data.boxMat = new BABYLON.StandardMaterial("box", scene);
        data.boxMat.specularColor = new BABYLON.Color3(0, 0, 0);

        data.bodyMat = new BABYLON.StandardMaterial("body", scene);
        data.bodyMat.specularColor = new BABYLON.Color3(0, 0, 0);

        data.wallMat = new BABYLON.StandardMaterial("wall", scene);
        data.wallMat.specularColor = new BABYLON.Color3(0, 0, 0);

        setColorScheme(data, 4);

        // Lights

        var light1 = new BABYLON.HemisphericLight("Hemi0", new BABYLON.Vector3(-2, 1.5, -3), scene);
        light1.intensity = 1.0;
        var light2 = new BABYLON.HemisphericLight("Hemi0", new BABYLON.Vector3(3, 1.5, 2), scene);
        light2.intensity = 0.5;

        data.box = new BABYLON.Mesh.CreateBox('box', 1, scene);
        data.box.material = data.boxMat;
        data.box.position = {
            x:-6,
            y:0.5,
            z:-6
        };

        data.ground = new BABYLON.Mesh.CreateGround('ground1', 21, 21, 2, scene);
        data.ground.material = new BABYLON.StandardMaterial("texture3", scene);
        data.ground.material.diffuseTexture = new BABYLON.Texture("assets/gridBlue.png", scene);
        data.ground.material.diffuseTexture.uScale = 21;
        data.ground.material.diffuseTexture.vScale = 21;
        data.ground.material.diffuseTexture.hasAlpha = true;

        scene.ambientColor = new BABYLON.Color3(1, 1, 1);                      // TO
        data.ground.material.diffuseColor = new BABYLON.Color3(0,0,0);         // PREVENT
        data.ground.material.specularColor = new BABYLON.Color3(0, 0, 0);      // LIGHT
        data.ground.material.ambientColor = new BABYLON.Color3(1,1,1);         // REFLECTION

        createFood(data);

        data.wall = [];

        data.wall[1] = new BABYLON.Mesh.CreateBox('wall', 1, scene);
        data.wall[1].position.x = 11;
        data.wall[1].scaling.z = 23;
        data.wall[2] = new BABYLON.Mesh.CreateBox('wall', 1, scene);
        data.wall[2].position.x = -11;
        data.wall[2].scaling.z = 23;
        data.wall[3] = new BABYLON.Mesh.CreateBox('wall', 1, scene);
        data.wall[3].position.z = 11;
        data.wall[3].scaling.x = 23;
        data.wall[4] = new BABYLON.Mesh.CreateBox('wall', 1, scene);
        data.wall[4].position.z = -11;
        data.wall[4].scaling.x = 23;

        for (var i = 1; i < data.wall.length; i++) {
            data.wall[i].material = data.wallMat;
        }

        return scene;
    };

    $('#alertEXT').html('<div class="alert alert-dark"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><h4><b>Swift Snake</b></h4>Collect food and evade your tail.<hr><b>Controls: &nbsp;</b><kbd>Arrow Keys</kbd> or <kbd>WASD</kbd><b><hr>Snake : <img src="assets/snakeS.png" alt="snake" style="height:20px"> <br> Food : <img src="assets/foodS.png" alt="food" style="height:20px"> <hr></b>Press <kbd>ENTER</kbd> to begin... </div>');
    $('#alertEXT').width(300);
    fixUI();
    scene = createScene();

    setInterval(function(){
        if(data.game){
            if(data.frameCount > 1) {
                move(data);
                data.frameCount = 0;
            }else{
                data.frameCount++;
            }
        }
    },17);

    scene.registerBeforeRender(function(){
        if (camera.beta > Math.PI / 2) {
            camera.beta = Math.PI / 2;
        }
        if (camera.alpha < Math.PI / 2) {
            camera.alpha = 5 * Math.PI / 2;
        }
        if (camera.alpha > 5 * Math.PI / 2) {
            camera.alpha = Math.PI / 2;
        }
        if(camera.radius < 7){
            camera.radius = 7;
        }
    });

    engine.runRenderLoop(function(){
        scene.render();
    });

    // Event binds
    $('#highscoreEXT').click(function(){
        this.blur();
        $('#alertEXT').html('<div class="alert alert-dark"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><b>Leaderboard </b> :<table id="scoreboard" class="table table-sm table-striped"></table><div id="scoreLoadWarn" class="alert alert-warning"><strong>Loading Scores</strong><br>Please wait... </div>Top 5 highscores worldwide. <br> Your nickname : <b>'+data.nickname+'</b></div>');
        data.socket.emit('get ranks');
        $('#alertEXT').width(300);
        fixUI();
    });
});

function move(data){
    if(data.queue.length > 0){
        switch(data.queue[0]){
            case 'right':
                if(data.dir != 'left'){
                    data.dir = data.queue[0]
                }
                break;
            case 'left':
                if(data.dir != 'right'){
                    data.dir = data.queue[0]
                }
                break;
            case 'up':
                if(data.dir != 'down'){
                    data.dir = data.queue[0]
                }
                break;
            case 'down':
                if(data.dir != 'up'){
                    data.dir = data.queue[0]
                }
                break;
        }
    }
    switch(data.queue.length){
        case 2:
            data.queue = [data.queue[1]];
            break;
        case 1:
            data.queue = [];
            break;
    }

	switch (data.dir){
		case "right":
            data.box.position.x++;
			break;
		case "left":
            data.box.position.x--;
			break;
		case "up":
            data.box.position.z++;
			break;
		case "down":
            data.box.position.z--;
			break;
	}
	data.snake.unshift({x: data.box.position.x, z: data.box.position.z});

	for(var i=0; i < data.body.length; i++){
		var d = i + 1;
        data.body[i].position.x = data.snake[d].x;
        data.body[i].position.z = data.snake[d].z;
	}

	// If the head collides with a food
	if(data.box.position.x == data.food.position.x && data.box.position.z == data.food.position.z){
		addBody(data);
	}

	// If the head hits one of the side walls
	if(Math.abs(data.box.position.x) > 10 || Math.abs(data.box.position.z) > 10){
        endGame(data);
    }
    // If the head collides with one of the body pieces
	for (var i = data.body.length-2; i > -1; i--) { // i = 1
		if(data.box.position.x == data.body[i].position.x && data.box.position.z == data.body[i].position.z){
			endGame(data);
            break;
		}
	}

    data.snake.pop();

	if(data.wobble) {
        camera.alpha = 3 * Math.PI / 2 - 0.02 * data.box.position.x;
        camera.beta = 0.75 - 0.02 * data.box.position.z;
    }
}


function setdir(e,data){
    if(data.queue.length < 2 && data.game){
         switch(e.keyCode){
            case 37:
                if(!data.queue.includes('left')) {
                    data.queue.push('left');
                }
                break;
            case 38:
                if(!data.queue.includes('up')) {
                    data.queue.push('up');
                }
                break;
            case 39:
                if(!data.queue.includes('right')) {
                    data.queue.push('right');
                }
                break;
            case 40:
                if(!data.queue.includes('down')) {
                    data.queue.push('down');
                }
                break;
            case 65:
                if(!data.queue.includes('left')) {
                    data.queue.push('left');
                }
                break;
            case 68:
                if(!data.queue.includes('right')) {
                    data.queue.push('right');
                }
                break;
            case 87:
                if(!data.queue.includes('up')) {
                    data.queue.push('up');
                }
                break;
            case 83:
                if(!data.queue.includes('down')) {
                    data.queue.push('down');
                }
                break;
        }
    }
    if(e.keyCode == 13){
        if(tempNick){
            startGame(data);
        }else if(typeof data.nickname == "undefined" || data.nickname == ""){
            enterNickname(data);
        }
    }
}

function enterNickname(data){
    var temp = $('#nickInput').val();
    if(!disconnected) {
        if(temp.replace(/\s/g, '') != ""){
            tempNick = temp.replace(/</g, " ").replace(/>/g, " ").slice(0, 15);
            data.socket.emit('check user', tempNick);
        }else{
            try{$('#tempEXT').remove();}catch(err){}
            $('.alert').append("<a id='tempEXT'><br><b>Plase enter a valid username...<br></b></a>")
        }
    }else{
        try{$('#tempEXTint').remove();}catch(err){}
        $('.alert').append("<a id='tempEXTint'><br><b>You need to connect to the internet in order to pick a nickname. <br>You can play offline once you've chosen a nickname.<br></b></a>")
    }
}

function connectSocket(dataMain,ip){
    dataMain.socket = io.connect(ip);

    dataMain.socket.on('connection check',function(data){
        disconnected = false;
    });

    dataMain.socket.on('ranks',function(data){
        if($('#scoreLoadWarn').html() != "") {
            $('#scoreboard').html('');
            $('#scoreLoadWarn').remove();
            for (var i = 0; i < 5; i++) {
                $('#scoreboard').append("<tr class='active'><td>" + data[i].name.replace(/</g, " ").replace(/>/g, " ").slice(0, 15) + "</td><td>" + data[i].score + "</td></tr>");
            }
            if (!(typeof dataMain.nickname == "undefined" || dataMain.nickname == "" || $('#chromesignin').length)) {
                $('#alertEXT').width(300);
            }
            try {
                $('#tempEXT').remove();
            } catch (err) {
            }
            fixUI();
        }
    });

    dataMain.socket.on('connect_error',function(){
        $('#tempEXT').remove();
        $('#scoreboard').html('');
        $('#errorBox').html('');
        $('#scoreLoadWarn').remove();
        $('#scoreboard').html("<tr class='danger'><td>Connection Failed...</td></tr>");
        $('#errorBox').html("<tr class='danger'><td>Connection Failed...</td></tr>");
        disconnected = true;
    });

    dataMain.socket.on('user return',function(data){
        if(data){
            chrome.storage.sync.set({'nickname': tempNick}, function(){});
            dataMain.nickname = tempNick;
            $('#alertEXT').html('<div class="alert alert-dark"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><h4><b>Swift Snake</b></h4>Collect food and evade your tail.<hr><b>Controls: &nbsp;</b><kbd>Arrow Keys</kbd> or <kbd>WASD</kbd><b><hr>Snake : <span class="glyphicon glyphicon-stop" aria-hidden="true" style="color:#81be2a"></span> <br> Food : <span class="glyphicon glyphicon-stop" aria-hidden="true" style="color:blue"></span><hr></b>Press <kbd>ENTER</kbd> to begin... </div>');
            $('#alertEXT').width(300);
            $('#alertEXT').css('height','auto');
            fixUI();
        }else{
            if(typeof $('#nickEnter').html() == "undefined"){
                dataMain.nickname = tempNick;
            }else{
                try{$('#tempEXT').remove();}catch(err){}
                $('.alert').append("<a id='tempEXT'><br><b>That name has been taken...<br></b></a>");
            }
        }
    });
}

function addBody(data){
    data.food.dispose();
    data.body[data.length] = new BABYLON.Mesh.CreateBox('body', 0.9, scene);
    data.body[data.length].position.y = 0.5;
    data.body[data.length].position.x = 9999;
    data.body[data.length].position.z = 9999;
    data.body[data.length].material = data.bodyMat;

    data.length++;
    data.snake.push({x:999,z:999});

    $('#pointsEXT').text('Points : '+data.length);
    fixUI();
	createFood(data);

}

function createFood(data){
    data.food = new BABYLON.Mesh.CreateBox('food', 0.9, scene);
    data.food.position.y = 0.5;
    data.food.position.x = Math.floor(Math.random() * 21) - 10;
    data.food.position.z = Math.floor(Math.random() * 21) - 10;
    while(foodIntersectsBody(data) || BABYLON.Vector3.Distance(data.food.position, data.box.position) < 2){
        data.food.position.x = Math.floor(Math.random() * 21) - 10;
        data.food.position.z = Math.floor(Math.random() * 21) - 10;
    }
    data.food.material = data.foodMat;
}

function foodIntersectsBody(data){
    for(var i=0;i<data.body.length-1;i++){
        if(data.food.position.x == data.body[i].position.x && data.food.position.z == data.body[i].position.z){
            return true
        }
    }
    return false
}

function endGame(data){
    chrome.storage.sync.get("highScore",function(info){
        data.currentHS = info.highScore;
    });
    if(data.length > data.currentHS){
        chrome.storage.sync.set({'highScore': data.length}, function(){});
        $('#highscoreEXT').text('Highscore : ' + data.length);
        data.currentHS = data.length;
    }
    //clearInteval(int);
    data.game = 0;
    data.box.position.x = -6;
    data.box.position.z = -6;
    $('#alertEXT').html('<div class="alert alert-dark"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><h5><b>GAME OVER</b></h5>Your final score is: <strong>'+data.length+'</strong><br><br><b>Global Leaderboard</b> :<table id="scoreboard" class="table table-sm table-striped"></table><div id="scoreLoadWarn" class="alert alert-warning"><strong>Loading Scores</strong><br>Please wait... </div>Press <kbd>ENTER</kbd> to play again... </div>');

    if(!disconnected){data.socket.emit('check highscore', {"name": data.nickname, "score": data.length, "token": 0});}

    fixUI();

    data.food.dispose();
    createFood(data);

    data.length = 0;
    for (var i = 0; i < data.body.length; i++) {
        data.body[i].dispose();
    }
    data.body = [];
    data.queue = [];
    data.dir = "right";
    $('#pointsEXT').text('Points : 0');
}

$('#viewEXT').click(function(){
    this.blur();
    if(!view){
        $("#viewEXT").html("3D");
        view = 1;
        camera.animations = [];

        var cameraTargetAnimation = new BABYLON.Animation("", "alpha", 30, BABYLON.Animation.ANIMATIONTYPE_FLOAT, BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
        var keys = [];
        keys.push({
            frame: 0,
            value: camera.alpha
        });
        keys.push({
            frame: 30,
            value: Math.PI/2*3
        });
        cameraTargetAnimation.setKeys(keys);
        camera.animations.push(cameraTargetAnimation);

        var cameraPositionAnimation = new BABYLON.Animation("", "beta", 30, BABYLON.Animation.ANIMATIONTYPE_FLOAT, BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
        var positionKeys = [];
        positionKeys.push({
            frame: 0,
            value: camera.beta
        });
        positionKeys.push({
            frame: 30,
            value: 0.001
        });
        cameraPositionAnimation.setKeys(positionKeys);
        camera.animations.push(cameraPositionAnimation);

        var cameraFovAnimation = new BABYLON.Animation("", "fov", 30, BABYLON.Animation.ANIMATIONTYPE_FLOAT, BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
        var fovKeys = [];
        fovKeys.push({
            frame: 0,
            value: camera.fov
        });
        fovKeys.push({
            frame: 30,
            value: 0.02
        });
        cameraFovAnimation.setKeys(fovKeys);
        camera.animations.push(cameraFovAnimation);

        var cameraRadiusAnimation = new BABYLON.Animation("", "radius", 30, BABYLON.Animation.ANIMATIONTYPE_FLOAT, BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
        var radiusKeys = [];
        radiusKeys.push({
            frame: 0,
            value: camera.radius
        });
        radiusKeys.push({
            frame: 30,
            value: 1390
        });
        cameraRadiusAnimation.setKeys(radiusKeys);
        camera.animations.push(cameraRadiusAnimation);

        scene.beginAnimation(camera, 0, 30, false);
    }else{
        $("#viewEXT").html("2D");
        view = 0;
        camera.animations = [];

        var cameraTargetAnimation = new BABYLON.Animation("", "alpha", 30, BABYLON.Animation.ANIMATIONTYPE_FLOAT, BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
        var keys = [];
        keys.push({
            frame: 0,
            value: camera.alpha
        });
        keys.push({
            frame: 30,
            value: 4.90978454023457
        });
        cameraTargetAnimation.setKeys(keys);
        camera.animations.push(cameraTargetAnimation);

        var cameraPositionAnimation = new BABYLON.Animation("", "beta", 30, BABYLON.Animation.ANIMATIONTYPE_FLOAT, BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
        var positionKeys = [];
        positionKeys.push({
            frame: 0,
            value: camera.beta
        });
        positionKeys.push({
            frame: 30,
            value: 0.9056002717820779
        });
        cameraPositionAnimation.setKeys(positionKeys);
        camera.animations.push(cameraPositionAnimation);

        var cameraFovAnimation = new BABYLON.Animation("", "fov", 30, BABYLON.Animation.ANIMATIONTYPE_FLOAT, BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
        var fovKeys = [];
        fovKeys.push({
            frame: 0,
            value: camera.fov
        });
        fovKeys.push({
            frame: 30,
            value: 0.8
        });
        cameraFovAnimation.setKeys(fovKeys);
        camera.animations.push(cameraFovAnimation);

        var cameraRadiusAnimation = new BABYLON.Animation("", "radius", 30, BABYLON.Animation.ANIMATIONTYPE_FLOAT, BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
        var radiusKeys = [];
        radiusKeys.push({
            frame: 0,
            value: camera.radius
        });
        radiusKeys.push({
            frame: 30,
            value: 33
        });
        cameraRadiusAnimation.setKeys(radiusKeys);
        camera.animations.push(cameraRadiusAnimation);


        scene.beginAnimation(camera, 0, 30, false);
    }
});

$('#aboutEXT').click(function(){
    this.blur();
    chrome.tabs.create({url:"https://www.oktaycomu.com/about.php"});
});

function startGame(data){
    $('#alertEXT').html('');
    fixUI();
    if(!data.game) {
        data.dir = "right";
        //int = setInterval(move, 50);
        data.game = 1;
    }
}

$(document).ready(function(){
    fixUI();
});

function fixUI(){
    var height = $('#renderCanvasEXT').height();
    var width = $('#renderCanvasEXT').width();

    $('#highscoreEXT').offset({left:16,top:30});
    $('#pointsEXT').offset({left:width - 44 - $('#pointsEXT').width(),top:30});
    $('#aboutEXT').offset({left:width - 44 - $('#aboutEXT').width(),top:height-80});
    $('#viewEXT').offset({left:16,top:height-80});
    $('#alertEXT').offset({left:width/2 - $('#alertEXT').width()/2,top:height/2-$('#alertEXT').height()/2+10});
}

function setColorScheme(data, c){
    switch(c){
        case 1:
            data.foodMat.diffuseColor = new BABYLON.Color3(237/255,245/255,150/255);
            data.boxMat.diffuseColor = new BABYLON.Color3(153/255,115/255,106/255);
            data.bodyMat.diffuseColor = new BABYLON.Color3(205/255,166/255,162/255);
            data.wallMat.diffuseColor = new BABYLON.Color3(115/255,132/255,153/255);
            break;
        case 2:
            data.foodMat.diffuseColor = new BABYLON.Color3(247/255,197/255,159/255);
            data.boxMat.diffuseColor = new BABYLON.Color3(189/255,219/255,161/255);
            data.bodyMat.diffuseColor = new BABYLON.Color3(209/255,239/255,181/255);
            data.wallMat.diffuseColor = new BABYLON.Color3(115/255,132/255,153/255);
            break;
        case 3:
            data.foodMat.diffuseColor = new BABYLON.Color3(183/255,148/255,146/255);
            data.boxMat.diffuseColor = new BABYLON.Color3(84/255,94/255,86/255);
            data.bodyMat.diffuseColor = new BABYLON.Color3(102/255,119/255,97/255);
            data.wallMat.diffuseColor = new BABYLON.Color3(115/255,132/255,153/255);
            break;
        case 4:
            data.foodMat.diffuseColor = new BABYLON.Color3(206/255,185/255,146/255);
            data.boxMat.diffuseColor = new BABYLON.Color3(153/255,115/255,106/255);
            data.bodyMat.diffuseColor = new BABYLON.Color3(205/255,166/255,162/255);
            data.wallMat.diffuseColor = new BABYLON.Color3(115/255,132/255,153/255);
            break;
    }
}

function setSkyBox(){
    skybox = BABYLON.Mesh.CreateBox("skyBox", 10000.0, scene);
    skyboxMaterial = new BABYLON.StandardMaterial("skyBox", scene);
    skyboxMaterial.backFaceCulling = false;
    skybox.material = skyboxMaterial;
    skybox.infiniteDistance = true;
    skyboxMaterial.diffuseColor = new BABYLON.Color3(0, 0, 1);
    skyboxMaterial.specularColor = new BABYLON.Color3(0, 0, 0);
    skyboxMaterial.reflectionTexture = new BABYLON.CubeTexture("assets/skybox/white", scene);
    skyboxMaterial.reflectionTexture.coordinatesMode = BABYLON.Texture.SKYBOX_MODE;
}
