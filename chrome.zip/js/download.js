function getUrl() {
    chrome.tabs.getSelected(null, function (tab) {
        tablink = tab.url;
    });
    return tablink;
}

$('#points').click(function(){
    this.blur();
    var url = getUrl();
    if(url.search("//www.youtube.com/watch") != -1){
        chrome.tabs.create({url:"http://www.convert2mp3.net/?url="+url});
    }
});

/*$(window).ready(function(){
    var url = window.location.href;
    alert('test');
    if(url.search("www.convert2mp3.net/") != -1 && url.search("url=") != -1){
        alert('hi');
        $('.mainbtn').click();
    }
});*/